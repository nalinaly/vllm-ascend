# DSV4 QR 验证上下文：原始日志第43～46节

## 43. 2026-09-22：完整B4图重放通过，QR与Indexer精度边界

QR单累加链与Native归约顺序版本：B4 `task_20260922_105033_92648422520`完整PASS；
B8重提任务`task_20260922_105920_144872130465`输出PASS（max_abs=0.009765625，
RMSE=0.001658857），Top-K仍76个位置不同，均位于query32；
B40 `task_20260922_105034_92674918555`输出4659、Top-K3476个位置超差。
六个cache/state及Native/PTO保护区均继续通过。

完整CSA图重放首轮`task_20260922_105640_130351314126`在capture前的测试地址签名中失败：
压缩组的合法`None` slot_mapping被调用data_ptr。测试签名保留显式None标记后，
`task_20260922_110453_161540122995`完成PASS：B4/S6，history131071与131073、页表交换，
A→B→A三个变体各30项检查通过；地址固定且使用真实Native ExternalEvent。
graph/eager输出、Top-K及五份完整allocation逐bit一致，Native数值与三套未写区域检查通过。
证据：`full_replay_b4_v2/full_replay.json`。该结果不代表连续100步状态轨迹或完整P3通过。

为区分QA矩阵乘与归一化，诊断捕获Native的`cv_wq_a.matmul`输出，并将生产链归一化
提取成同一`q_proj_qr_normalize`函数供诊断复用，未另写QKV计算。
B8 `task_20260922_110452_161493814420`与B40 `task_20260922_110453_161500220966`
确认：给定Native QA后，B8 QR INT8完全一致但scale有12个末位差；B40仍有8个INT8差异、
55个scale末位差（最大1.74623e-10），说明归一化内部仍有舍入边界不同。
B40实际QA路径比给定Native QA多2个scale差异，最大1.62399e-8，后续仍须核对QA。

同一B40诊断给定Native QR后，Indexer RoPE后14个BF16元素不同。
用已捕获QR/scale与checkpoint INT8权重在CPU计算精确整数点积，非RoPE列比较：
`(acc*activation_scale)*weight_scale`有7个差异，反向依次乘有3个，
`acc*(activation_scale*weight_scale)`为0个。故在本仓库Indexer QB先合并两尺度。
同时使用PyPTO现有`pl.div(..., high_precision=True)`核对Native标量FP32除法，
只调整QR的rstd、量化乘数及其倒数；未修改PyPTO/Simpler/pypto-lib。
这两项改动尚待CPU lowering与B4/B8/B40真机验证，不预记PASS，不变更冻结阈值。

三组`qr_div_scale_*_v1`完成：B4 `task_20260922_111407_215756026152`完整PASS；
B8 `task_20260922_111407_215768123020`输出PASS、Top-K179个位置不同；
B40 `task_20260922_111407_21578172762`输出3832、Top-K2481个差异。
Indexer给定Native QR后的BF16、INT8 query及scale在三组均逐bit相同，证明尺度合并顺序修正有效。
QR与其scale差异未变；生成代码已含`TDIV<DivAlgorithm::HIGH_PRECISION>`，但只读核对
当前PTO-ISA `include/pto/npu/a2a3/TDiv.hpp`发现`TDIV_IMPL`未使用PrecisionType，仍调用vdiv。
因此不能把选项存在当作实际改变精度的证据。下一版在本仓库改用设备端scalar除法计算
rstd与两种scale，复用已有read/write接口，未改PTO-ISA或编译器，未增加host取值。

设备标量除法`qr_scalar_div_*_v1`：B4 `task_20260922_112128_261394329244`完整PASS；
B8 `task_20260922_112128_26140063420`输出PASS、Top-K179个差异（仅query41）；
B40 `task_20260922_112128_261410714842`QR INT8已经完全一致，输出超差降至351个、
Top-K867个差异（query29/41/46/161/184）。六个cache/state及保护区继续通过。
给定Native QA后scale剩B8六个、B40二十一个末位差；B40实际QA路径另有八行scale不同。
为核对sqrt与归约，从现有生产函数提取`q_proj_qr_rms`并复用它采集平方和/rstd。
首次lowering无法推断传入cast临时Tensor的metadata，改为传已有GM Tensor与行偏移后通过，
未修改编译器。B40诊断任务`task_20260922_112531_27738519184`已提交。
Indexer反量化CPU验证证据已保存到`qr_boundary_b40_v1/dequant_order_cpu.json`。

## 44. 2026-09-22：QR平方根的末位定位

`qr_rms_boundary_b40_v1`完成，完整结果仍FAIL。诊断复用生产归约函数采集平方和与rstd；
用同一PTO平方和在CPU按Native顺序执行`1/sqrt(sum/1024+eps)`及真实Tensor/Tensor除法，
240行QR和scale均与Native逐bit一致；用PTO rstd重算则恰好复现21个scale差异。
证据保存在`qr_rms_boundary_b40_v1/rms_cpu_analysis.json`。

新增`qr_boundary`轻量入口，仅给定已捕获Native QA，调用同一生产归一化函数，
可减少定位时整层重复执行。它不是完整CSA或目标权重验收。
首个任务`task_20260922_113032_32463537237`按预期FAIL（QR 0、scale21差异），
同时采出sqrt：PTO VSQRT与CPU sqrt有25个FP32末位差，设备scalar倒数与同输入CPU倒数0差异。
归约及设备标量除法均已排除，剩余scale差异由VSQRT的舍入引起。

为保留只读依赖约束，在本仓库QR中对VSQRT候选值做整数中点比较：
比较输入与相邻FP32平方根中点的平方；24位significand对应的比较整数小于2^52，
全部用设备INT64运算，避免再次引入浮点误差，并保留round-to-even边界。
EPS保证有效输入为正normal值，非有限值保留原结果。CPU以501024个正normal输入及
幂次边界验证、随机给正确sqrt加减1 ULP后恢复，0差异。
CPU lowering通过`csa_qr_sqrt_round_lower/report.json`；轻量B40与完整B8/B40任务记录在
`qr_sqrt_round_v1_manifest.json`，尚待真机结果；冻结阈值和Native算子未修改。

三项完成：轻量B40 `task_20260922_113343_356263113412` PASS，240行QR INT8与scale逐bit一致；
采集的sqrt、rstd与同一平方和的CPU参考均0差异（`sqrt_cpu_check.json`）。
完整B8 `task_20260922_113343_356267121789` PASS：Top-K 24576个位置完全相同，
输出max_abs=0.009765625、RMSE=0.0016587045；全部cache/state和未写区域通过。
完整B40 `task_20260922_113343_356273718818`仍FAIL：输出351、Top-K697个差异，
QR INT8为0差异，scale仅8行不同；给定Native QA后的QR与scale及Indexer边界均逐bit一致。
剩余差异定位到QA累加/发布边界，下一步提取同一QA matmul供诊断复用并采集FP32累加值。

## 45. 2026-09-22：QA累加边界诊断

共享`q_proj_qa`提取初版lowering通过但NPU代码生成失败，任务
`task_20260922_113748_370395527032`未执行PTO core：reshape shape内直接调用tensor.dim
无法生成表达式。恢复为先定义标量再reshape后，任务`task_20260922_113904_37353251679`
完整执行，结果与提取前一致；QA发布BF16有32个值不同，QR INT8相同、scale仍8行不同。
所有提取函数仍位于本仓库，数学运算未另写，未修改依赖。

用同一hidden与BF16权重做CPU FP64点积后舍入BF16：Native有27个、PTO有30个差异。
Native/PTO的32个不同值多处靠近BF16舍入中点或发生相消，不能用更高精度CPU结果
直接替换Native的实际累加行为。CPU结果保存在`qa_boundary_b40_v1/cpu_qa.pt`。

轻量入口增加`--include-projection`，复用生产QA和归一化：
K tile由256临时改为512，任务`task_20260922_114136_382108919779`仍为QA32、QR0、scale8差异；
恢复K256后测试split-K=2，任务`task_20260922_114250_389839224305`为QA34、QR2、scale10差异。
两项试验均未改善，已恢复K256、单累加链。未把调参试验记为正式通过。
下一项观测使用相同Native QA输入，记录linear、连续B、M分块和FP32路径的输出及profiler，
用于确认实际Native算子路径；该观察不修改基线或验收规则。

`task_20260922_114537_5305516886`完成Native QA观测：直接linear与原捕获值0差异，
改为连续B存储有30个BF16差异，按48行分块有32个，FP32输入路径再转BF16有29个。
PTO QA与Native按48行分块结果逐bit完全一致，而与连续B结果有9个差异。
这证明剩余差异与Native大M/转置路径的累加顺序有关，不能靠提高数学精度或改验收基线解决。
初次profiler仅记录aclnnMatmul_MatMulCommon_MatMulV2，继续采集Level1及op args核对实际路径。

完整回归：B4 `task_20260922_114638_9471112876` PASS，输出max_abs=0.0087890625、
RMSE=0.0016623752，cache/state/Top-K/保护区全部通过。
B8完整图`task_20260922_114638_947516243` PASS：history131071/131073/131071，
三个变体各30项检查通过，地址固定、Native外部事件保留，graph/eager整份allocation逐bit一致。
证据为`full_replay_b8_v1/full_replay.json`，仍不替代连续100步状态轨迹。

Level1观测`task_20260922_114822_19671432009`已完成。Native QA实际使用CANN9.0的
legacy `MatMulV2_ND_ND_FP16_FP16_false_true_all.o`，BF16输入、NT布局、22个Cube core，
不是MatMulV3。读取该二进制compileInfo和实际op args，在CPU调用现有`do_op_tiling`：
M48得到tiling_key=98883，M240得到99025，均无跨core split-K。
解码结果保存于`qa_native_observation_b40_v2/cpu_native_tiling.json`。
M48的A L1一次装入全部K4096；M240的A/B L1均按K256分块，L0 K128。
只读核对CANN调度发现大M路径可执行`shift_block_access`，循环移动K访问起点；
当前继续核对该累加顺序，不把tiling差异本身视为已修复，也不修改Native基线。
CPU tiling查询首次因缺少`ori_shape`失败，补齐字段后查询成功；首次保存bytes到JSON失败，
改为保存hex、uint32及字段解码后成功。上述失败均未运行NPU计算。

QA K顺序观测复用`diagnose_qa`/生产`q_proj_qa`，仅把两输入的K维同步循环排列，
不写另一套matmul。`task_20260922_120239_140435110970`枚举K256起点，
`task_20260922_120436_148213828070`按Native L0粒度枚举K128起点，均完成exit=0。
该exit=0只表示观测完成及给定Native QA的归一化仍PASS，不表示观测QA已通过。
两份`qa_k_rotations.json`显示，N96分块中的第1/5/7块没有任何统一起点能完全对齐；
K256观测另有第3块不能对齐。故单一循环起点假设不足，不能据此写入生产QA。
生产QA仍为K256、单累加链；结果与完成时源码hash见`qa_k_rotation_manifest.json`。
补充CPU六档形状tiling查询在`qa_native_observation_b40_v2/cpu_six_shape_tiling.json`。
本轮未改变数值容差、Native基线或依赖仓库，B40完整结果仍为输出351/Top-K697个差异。

## 46. 2026-09-22：定位Native QA的正反向K调度

上轮取得实际tiling及K起点观测，属于有效进展；本轮继续核对生成代码。
先按Native L0 K128测试生产QA，任务`task_20260922_121101_198845131022`完成FAIL：
QA32、QR0、scale8差异，K128起点观测也与K256版本相同。已逐字节恢复试验前K256源码，
未把无效调参保留为修复。

CPU尝试调用CANN动态入口缺少range、直接静态入口缺少compute context，均在编译前失败。
随后复用安装版`_binary_constant_branch`成功生成同形状CANN MatMulV2代码；
不修改CANN/TBE或任一依赖。首个证据为
`qa_native_codegen_b40_v3/kernel_meta/csa_native_qa_observe.cce`。
可复跑的六档CPU观察脚本及生成源位于`qa_native_codegen_six/`，六项生成均完成。

M96/144/192/240的生成代码给出相同规则：令`g=column//96`、`k=0..15`，
第0～8个N组的K256块顺序为
`(3*(g//2) + (k if g%2==0 else 15-k)) % 16`；第9/10组处于重叠尾区，不移动K顺序。
奇数组不仅移动起点，还反向遍历256块，但块内元素仍保持正序，解释了前轮单纯rotation
无法完全匹配第1/3/5/7组。M24/M48生成代码没有这项调度。

本仓库`q_proj_qa`按上述规则调整现有K遍历；N tile改为32，避免跨Native的96列顺序边界。
保留K256、单FP32累加器、已有QA BF16发布及QR函数链；未改Native基线。
首版仅M240，轻量任务`task_20260922_121633_20855309404`完成PASS：
QA BF16、QR INT8和scale全部0差异。随后按已生成源扩展至M96/144/192，
六档完整CSA对照任务与源码hash记于`qa_native_full_v1_manifest.json`，尚待结果。

六项完整对照均已完成PASS：B4 `task_20260922_121803_213381718645`、
B8 `task_20260922_121803_21338577904`、B16 `task_20260922_121803_213389714639`、
B24 `task_20260922_121803_213399211069`、B32 `task_20260922_121803_213410912351`、
B40 `task_20260922_121803_213426623243`。
B40 history131071，其余history131072；各项输出、Top-K、六个cache/state及全部未写区域通过，
B40原先351个输出超差与697个Top-K位置差异均归零。
以同一源码补齐其余12组长度组合，完整18组清单在`reference_matrix_v2/manifest.json`；
同时提交B40 A→B→A完整图对照，尚待结果。上述均为参考权重验证，正式目标checkpoint未加载。

